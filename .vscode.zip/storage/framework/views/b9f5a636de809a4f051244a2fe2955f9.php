<?php $__env->startSection('main'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/admin_style.css')); ?>">



<header class="header">

    <section class="flex">

        <a href="<?php echo e(url('/dashboardad')); ?>" class="logo">Tutor.</a>

        <form action="<?php echo e(route('caricommentsad')); ?>" method="post" class="search-form">
            <?php echo csrf_field(); ?>
            <input type="text" name="search" placeholder="Cari komentar..." required maxlength="100">
            <button type="submit"><i class="fas fa-search"></i></button>
        </form>


        <div class="icons">
            <div id="menu-btn" class="fas fa-bars"></div>
            <div id="search-btn" class="fas fa-search"></div>
            <div id="user-btn" class="fas fa-user"></div>
            <div id="toggle-btn" class="fas fa-sun"></div>
        </div>

        <div class="profile">

            <img src="<?php echo e(asset('uploaded_files/' . $userImage)); ?>" alt="">
            <h3><?php echo e($userName); ?></h3>
            <span><?php echo e($userProfesi); ?></span>
            <a href="<?php echo e(url('/profileadmin')); ?>" class="btn">view profile</a>

            <a href="../components/admin_logout.php" onclick="return confirm('logout from this website?');"
                class="delete-btn">logout</a>

        </div>

    </section>

</header>


<section class="comments">
    <h1 class="heading">User Comments</h1>

    <div class="show-comments">
       <?php if($comments->count() > 0): ?>
          <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <div class="box" style="<?php echo e($comment->tutor_id == $tutor_id ? 'order:-1;' : ''); ?>">
                <div class="content"><span><?php echo e($comment->date); ?></span><p> - <?php echo e($comment->user_name); ?> - </p>
                    
                </div>
                <p class="text"><?php echo e($comment->comment); ?></p>
                <!-- Tampilkan nama pengguna -->
                
                <form action="<?php echo e(route('delete.comment')); ?>" method="post">
                   <?php echo csrf_field(); ?>
                   <input type="hidden" name="comment_id" value="<?php echo e($comment->id); ?>">
                   <button type="submit" name="delete_comment" class="inline-delete-btn" onclick="return confirm('Delete this comment?');">Delete Comment</button>
                </form>
             </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       <?php else: ?>
          <p class="empty">No comments added yet!</p>
       <?php endif; ?>
    </div>
 </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel asik cik\codinggo web\resources\views/commentsad.blade.php ENDPATH**/ ?>