<?php $__env->startSection('main'); ?>
<link rel="stylesheet" href="assets/css/admin_style.css">

<header class="header">

    <section class="flex">

        <a href="<?php echo e(url('/dashboardsp')); ?>" class="logo">Admin.</a>

        

        <div class="icons">
            <div id="menu-btn" class="fas fa-bars"></div>
            <div id="search-btn" class="fas fa-search"></div>
            <div id="user-btn" class="fas fa-user"></div>
            <div id="toggle-btn" class="fas fa-sun"></div>
        </div>

        <div class="profile">

            <img src="<?php echo e(asset('uploaded_files/' . $userImage)); ?>" alt="">
            <h3><?php echo e($userName); ?></h3>
            <span><?php echo e($userProfesi); ?></span>
            <a href="<?php echo e(url('/profilesp')); ?>" class="btn">view profile</a>

            <a href="<?php echo e(route('logoutsp')); ?>" onclick="return confirm('Anda Yakin Ingin Logout?');"
            class="delete-btn">logout</a>

        </div>

    </section>

</header>

<section class="tutor-profile" style="min-height: calc(100vh - 19rem);">

    <h1 class="heading">profile details</h1>

    <div class="details">

       <div class="tutor">
        <img src="<?php echo e(asset('uploaded_files/' . $userImage)); ?>" alt="">
        <h3><?php echo e($userName); ?></h3>
        <span><?php echo e($userProfesi); ?></span>
        <a href="<?php echo e(route('tutors.editsp', $tutorsId)); ?>" class="inline-btn">update profile</a>
       </div>

       <div class="flex">
        <div class="box">
           <span><?php echo e($totalTutors); ?></span>
           <p>Total Tutor</p>
           <a href="<?php echo e(route('tutor.index')); ?>" class="btn">view Tutor</a>
        </div>
        <div class="box">
           <span><?php echo e($totalUsers); ?></span>
           <p>Total Siswa</p>
           <a href="<?php echo e(route('siswa.index')); ?>" class="btn">view Siswa</a>
        </div>
        <div class="box">
           <span></span>
           <p>Total Pendapatan</p>
           <a href="" class="btn">view Transaksi</a>
        </div>
        
     </div>

    </div>

 </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.spheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel asik cik\codinggo web2\resources\views/profilesp.blade.php ENDPATH**/ ?>