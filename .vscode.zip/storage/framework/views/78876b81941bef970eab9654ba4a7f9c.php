<?php $__env->startSection('main'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('sidebarad', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel asik cik\codinggo web\resources\views/kursus.blade.php ENDPATH**/ ?>