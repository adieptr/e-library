<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="description" content="A simple HTML5 Template">
<meta name="author" content="dron">
<meta name="viewport" content="width=device-width, height=device-height, user-scalable=no, initial-scale=1.0, maximum-scale=1.0">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<link rel="shortcut icon" href="/favicon.ico">
<link rel="stylesheet" href="images/index.css">

</head>
<body>
<div id="extra"></div>
<div id="desc">
	<div id="browser"></div>
</div>
<script src="scripts/all.js"></script>
</body>
</html><?php /**PATH C:\Users\farai\OneDrive\Dokumen\SMT 4\Project Codinggo\codinggo\codinggo web2\resources\views/games/ninja.blade.php ENDPATH**/ ?>