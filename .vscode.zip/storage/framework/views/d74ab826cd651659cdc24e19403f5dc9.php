<?php $__env->startSection('main'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/admin_style.css')); ?>">


<header class="header">

    <section class="flex">

        <a href="<?php echo e(url('/dashboardsp')); ?>" class="logo">Admin.</a>

        <form action="<?php echo e(route('tutor.caritutor')); ?>" method="post" class="search-form">
            <?php echo csrf_field(); ?>
            <input type="text" name="search" placeholder="Cari Tutor..." required maxlength="100">
            <button type="submit" class="fas fa-search" name="search_btn"></button>
        </form>

        <div class="icons">
            <div id="menu-btn" class="fas fa-bars"></div>
            <div id="search-btn" class="fas fa-search"></div>
            <div id="user-btn" class="fas fa-user"></div>
            <div id="toggle-btn" class="fas fa-sun"></div>
        </div>

        <div class="profile">

            <img src="<?php echo e(asset('uploaded_files/' . $userImage)); ?>" alt="">
            <h3><?php echo e($userName); ?></h3>
            <span><?php echo e($userProfesi); ?></span>
            <a href="<?php echo e(url('/profilesp')); ?>" class="btn">view profile</a>

            <a href="../components/admin_logout.php" onclick="return confirm('logout from this website?');"
                class="delete-btn">logout</a>

        </div>

    </section>

</header>


<section class="playlists">
    <h1 class="heading">Tambah Tutor</h1>
    <div class="box-container">
       <div class="box" style="text-align: center;">
          <h3 class="title" style="margin-bottom: .5rem;">Buat Tutor Baru</h3>
          <a href="<?php echo e(url('/tambahtutor')); ?>" class="btn">Tambah Tutor</a>
       </div>
       <?php $__currentLoopData = $playlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $playlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <div class="box">
          <div class="flex">
             
          </div>
          <div class="thumb">
             
             <img src="<?php echo e(asset('uploaded_files/' . $playlist->image)); ?>" alt="">
          </div>
          <h3 class="title"><?php echo e($playlist->name); ?></h3>
          <p class="description"><?php echo e($playlist->profession); ?></p>
          <form action="" method="post" class="flex-btn">
            <?php echo csrf_field(); ?>
             <input type="hidden" name="playlist_id" value="">
             <a href="" class="option-btn">Update</a>
             <input type="submit" value="Delete" class="delete-btn" onclick="return confirm('Delete this playlist?');" name="delete">
          </form>
          <a href="<?php echo e(route('detailsiswa.showPlaylistad', ['id' => $playlist->id])); ?>" class="btn">View Detail</a>
       </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
 </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.spheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel asik cik\codinggo web\resources\views/viewtutor.blade.php ENDPATH**/ ?>