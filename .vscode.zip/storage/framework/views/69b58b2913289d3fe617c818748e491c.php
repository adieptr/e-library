<?php $__env->startSection('main'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/dash.css')); ?>">
<script src="<?php echo e(asset('assets/js/user_script.js')); ?>"></script>
<section class="form-container" style="min-height: calc(100vh - 19rem);">

    <form action="<?php echo e(route('user.update', $data->id)); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
       <h3>Update Profile</h3>
       <div class="flex">
          <div class="col">
             <p>Nama Lengkap :</p>
             <input type="text" name="name" placeholder="<?php echo e($data->name); ?>" maxlength="100" class="box">
             <p>Alamat Email :</p>
             <input type="email" name="email" placeholder="<?php echo e($data->email); ?>" maxlength="100" class="box">
             <p>Unggah Foto Profil :</p>
             <input type="file" name="image" accept="image/*" class="box">
          </div>
          
       </div>
       <input type="submit" name="submit" value="update profile" class="btn">
    </form>

 </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.userheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\farai\OneDrive\Dokumen\SMT 4\Project Codinggo\codinggo web2\resources\views/updateprofileu.blade.php ENDPATH**/ ?>