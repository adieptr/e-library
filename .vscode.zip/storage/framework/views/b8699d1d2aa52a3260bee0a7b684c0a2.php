<?php $__env->startSection('main'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/admin_style.css')); ?>">








<section class="playlist-form">
    <h1 class="heading">Update Transaksi</h1>

    <form action="<?php echo e(route('transaksi.update', $transaksi->id_transaksi)); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?> <!-- Tambahkan CSRF token untuk keamanan form -->
        <?php echo method_field('PUT'); ?>

        <!-- Input tersembunyi untuk menyimpan ID playlist -->
        <input type="hidden" name="get_id" value="<?php echo e($transaksi->id_transaksi); ?>">

        <p>-- Status Pembayaran --<span>*</span></p>
        <select name="status" class="box" required>
            
            <option value="ongoing" <?php echo e($dtlsiswa->status == "ongoing" ? 'selected' : ''); ?>>Lunas</option>
            <option value="pending" <?php echo e($dtlsiswa->status == "pending" ? 'selected' : ''); ?>>Belum Lunas</option>
        </select>

        <p>Nama Siswa<span>*</span></p>
        <input type="text" name="title" maxlength="100" required placeholder="Enter playlist title" value="<?php echo e($siswa->name); ?>" class="box" disabled>

        <p>Nama Kurus<span>*</span></p>
        <input type="text" name="title" maxlength="100" required placeholder="Enter playlist title" value="<?php echo e($course->title); ?>" class="box" disabled>

        <p>Bukti Pembayaran<span>*</span></p>
        <div class="thumb" style="height: 62rem;">
            <img src="<?php echo e(asset('uploaded_files/' . $transaksi->bukti_pembayaran)); ?>" alt="Playlist Thumbnail">
        </div>

        <p>Harga<span>*</span></p>
        <input type="text" name="harga" maxlength="100" required placeholder="Masukkan Harga" value="<?php echo e($course->harga); ?>" class="box" disabled>

        <input type="submit" value="Update Transaksi" name="submit" class="btn">
    </form>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.spheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\farai\OneDrive\Dokumen\SMT 4\Project Codinggo\codinggo web2\resources\views/update_transaksi.blade.php ENDPATH**/ ?>