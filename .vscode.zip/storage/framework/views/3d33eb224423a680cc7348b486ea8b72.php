<?php $__env->startSection('main'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/admin_style.css')); ?>">



<header class="header">

    <section class="flex">

        <a href="<?php echo e(url('/dashboardad')); ?>" class="logo">Tutor.</a>



        <div class="icons">
            <div id="menu-btn" class="fas fa-bars"></div>
            <div id="search-btn" class=""></div>
            <div id="user-btn" class="fas fa-user"></div>
            <div id="toggle-btn" class="fas fa-sun"></div>
        </div>

        <div class="profile">

            <img src="<?php echo e(asset('uploaded_files/' . $userImage)); ?>" alt="">
            <h3><?php echo e($userName); ?></h3>
            <span><?php echo e($userProfesi); ?></span>
            <a href="<?php echo e(url('/profileadmin')); ?>" class="btn">view profile</a>

            <a href="../components/admin_logout.php" onclick="return confirm('logout from this website?');"
                class="delete-btn">logout</a>

        </div>

    </section>

</header>


<section class="video-form">

    <h1 class="heading">Update Content</h1>

    <?php if($content): ?>
    <form action="<?php echo e(route('update.content', ['videoId' => $content->id])); ?>" method="post" enctype="multipart/form-data">
       <?php echo csrf_field(); ?>
       <input type="hidden" name="video_id" value="<?php echo e($content->id); ?>">
       <input type="hidden" name="old_thumb" value="<?php echo e($content->thumb); ?>">
       <input type="hidden" name="old_video" value="<?php echo e($content->video); ?>">
       <p>Update Status <span>*</span></p>
       <select name="status" class="box" required>
          <option value="<?php echo e($content->status); ?>" selected><?php echo e($content->status); ?></option>
          <option value="active">Active</option>
          <option value="deactive">Deactive</option>
       </select>
       <p>Update Title <span>*</span></p>
       <input type="text" name="title" maxlength="100" required placeholder="Enter video title" class="box" value="<?php echo e($content->title); ?>">
       <p>Update Description <span>*</span></p>
       <textarea name="description" class="box" required placeholder="Write description" maxlength="1000" cols="30" rows="10"><?php echo e($content->description); ?></textarea>
       <p>Update Playlist</p>
       <select name="playlist" class="box">
          <option value="<?php echo e($content->playlist_id); ?>" selected>--Select playlist</option>
          <?php $__currentLoopData = $playlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $playlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <option value="<?php echo e($playlist->id); ?>"><?php echo e($playlist->title); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </select>
       <img src="../uploaded_files/<?php echo e($content->thumb); ?>" alt="">
       <p>Update Thumbnail</p>
       <input type="file" name="thumb" accept="image/*" class="box">
       <video src="../uploaded_files/<?php echo e($content->video); ?>" controls></video>
       <p>Update Video</p>
       <input type="file" name="video" accept="video/*" class="box">
       <input type="submit" value="Update Content" name="update" class="btn">

    </form>
    <?php else: ?>
    <p class="empty">Video not found! <a href="add_content.php" class="btn" style="margin-top: 1.5rem;">Add videos</a></p>
    <?php endif; ?>

 </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel asik cik\codinggo web\resources\views/update_content.blade.php ENDPATH**/ ?>