<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin (<?php echo e($userName); ?>)</title>

    <!-- Font Awesome CDN link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

    <!-- Custom CSS file link -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/admin_style.css')); ?>">
    <link rel="icon" href="<?php echo e(asset('assets/images/demo/start-hub-2/logo/sidelogo.png')); ?>">

</head>

<body>
    

    <!-- header section ends -->

    <!-- side bar section starts  -->

    <div class="side-bar">

        <div class="close-side-bar">
            <i class="fas fa-times"></i>
        </div>

        <div class="profile">

            <img src="<?php echo e(asset('uploaded_files/' . $userImage)); ?>" alt="">
            <h3><?php echo e($userName); ?></h3>
            <span><?php echo e($userProfesi); ?></span>
            <a href="<?php echo e(url('profilesp')); ?>" class="btn">View Profile</a>

        </div>

        <nav class="navbar">
            <a href="<?php echo e(url('/dashboardsp')); ?>"><i class="fas fa-home"></i><span>Beranda</span></a>
            <a href="<?php echo e(route('tutor.index')); ?>"><i class="fa-solid fa-bars-staggered"></i><span>Tutor</span></a>
            <a href="<?php echo e(route('siswa.index')); ?>"><i class="fas fa-graduation-cap"></i><span>Siswa</span></a>
            <a href="<?php echo e(route('pages.datatransaksi')); ?>"><i class="fa-solid fa-circle-dollar-to-slot"></i><span>Transaksi</span></a>
            <a href="<?php echo e(route('logoutsp')); ?>" onclick="return confirm('Anda Yakin Ingin Logout?');"><i class="fas fa-right-from-bracket"></i><span>Log out</span></a>

        </nav>

    </div>

    <!-- side bar section ends -->
    <main>
        <?php echo $__env->yieldContent('main'); ?>
    </main>
    <script src="<?php echo e(asset('assets/js/admin_script.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\laravel asik cik\codinggo web2\resources\views/components/spheader.blade.php ENDPATH**/ ?>