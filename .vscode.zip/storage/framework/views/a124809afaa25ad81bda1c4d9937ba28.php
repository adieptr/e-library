<?php $__env->startSection('main'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/admin_style.css')); ?>">



<header class="header">

    <section class="flex">

        <a href="<?php echo e(url('/dashboardad')); ?>" class="logo">Tutor</a>



        <div class="icons">
            <div id="menu-btn" class="fas fa-bars"></div>
            <div id="search-btn" class="fas fa-search"></div>
            <div id="user-btn" class="fas fa-user"></div>
            <div id="toggle-btn" class="fas fa-sun"></div>
        </div>

        <div class="profile">

            <img src="<?php echo e(asset('uploaded_files/' . $userImage)); ?>" alt="">
            <h3><?php echo e($userName); ?></h3>
            <span><?php echo e($userProfesi); ?></span>
            <a href="<?php echo e(url('/profileadmin')); ?>" class="btn">View Profile</a>

            <a href="<?php echo e(route('logoutad')); ?>" onclick="return confirm('Anda Yakin Ingin Logout?');"
            class="delete-btn">Log out</a>

        </div>

    </section>

</header>


<section class="video-form">

    <h1 class="heading">Update Materi</h1>

    <?php if($content): ?>
    <form action="<?php echo e(route('update.content', ['videoId' => $content->id])); ?>" method="post" enctype="multipart/form-data">
       <?php echo csrf_field(); ?>
       <input type="hidden" name="video_id" value="<?php echo e($content->id); ?>">
       <input type="hidden" name="old_thumb" value="<?php echo e($content->thumb); ?>">
       <input type="hidden" name="old_video" value="<?php echo e($content->video); ?>">
       <p>Status Materi <span>*</span></p>
       <select name="status" class="box" required>
          <option value="<?php echo e($content->status); ?>" selected><?php echo e($content->status); ?></option>
          <option value="active">Aktif</option>
          <option value="deactive">Nonaktif</option>
       </select>
       <p>Judul Materi <span>*</span></p>
       <input type="text" name="title" maxlength="100" required placeholder="Enter video title" class="box" value="<?php echo e($content->title); ?>">
       <p>Deskripsi Materi <span>*</span></p>
       <textarea name="description" class="box" required placeholder="Write description" maxlength="1000" cols="30" rows="10"><?php echo e($content->description); ?></textarea>
       <p> Sesi Kursus </p>
       <select name="playlist" class="box">
          <option value="<?php echo e($content->playlist_id); ?>" selected>-- Pilih Kursus --</option>
          <?php $__currentLoopData = $playlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $playlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <option value="<?php echo e($playlist->id); ?>"><?php echo e($playlist->title); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </select>
       <img src="../uploaded_files/<?php echo e($content->thumb); ?>" alt="">
       <p>Unggah Foto Materi</p>
       <input type="file" name="thumb" accept="image/*" class="box">
       <video src="../uploaded_files/<?php echo e($content->video); ?>" controls></video>
       <p>Unggah Video Materi</p>
       <input type="file" name="video" accept="video/*" class="box">
       <input type="submit" value="Update" name="update" class="btn">

    </form>
    <?php else: ?>
    <p class="empty">Video tidak ditemukan! <a href="add_content.php" class="btn" style="margin-top: 1.5rem;">Tambah Video</a></p>
    <?php endif; ?>

 </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\farai\OneDrive\Dokumen\SMT 4\Project Codinggo\codinggo web2\resources\views/update_content.blade.php ENDPATH**/ ?>