<?php $__env->startSection('main'); ?>

<section class="courses">

    <h1 class="heading">Game</h1>

    <div class="box-container">


        <div class="box">
            <img src="assets/images/tictac.png" class="thumb" alt="">
            <h3 class="title">TicTacToc Game</h3>
            <a href="<?php echo e(route('pages.tictac')); ?>" class="inline-btn">Mainkan</a>
        </div>
        <div class="box">
            <img src="assets/images/memory.png" class="thumb" alt="">
            <h3 class="title">Memory Card Eazy</h3>
            <a href="<?php echo e(route('pages.cardlv1')); ?>" class="inline-btn">Mainkan</a>
        </div>
        <div class="box">
            <img src="assets/images/batu.png" class="thumb" alt="">
            <h3 class="title">Batu Gunting Kertas</h3>
            <a href="<?php echo e(route('pages.batu')); ?>" class="inline-btn">Mainkan</a>
        </div>
        <div class="box">
            <img src="assets/images/ular.png" class="thumb" alt="">
            <h3 class="title">Ular Classic</h3>
            <a href="<?php echo e(route('pages.ular')); ?>" class="inline-btn">Mainkan</a>
        </div>
        <div class="box">
            <img src="assets/images/gambar.png" class="thumb" alt="">
            <h3 class="title">Mari Menggambar</h3>
            <a href="<?php echo e(route('pages.gambar')); ?>" class="inline-btn">Mainkan</a>
        </div>
        <div class="box">
            <img src="assets/images/ninja.png" class="thumb" alt="">
            <h3 class="title">Fruit Ninja</h3>
            <a href="<?php echo e(route('pages.ninja')); ?>" class="inline-btn">Mainkan</a>
        </div>



    </div>

</section>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.userheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\farai\OneDrive\Dokumen\SMT 4\Project Codinggo\codinggo web2\resources\views/game.blade.php ENDPATH**/ ?>