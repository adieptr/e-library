<?php $__env->startSection('main'); ?>
    <header>
        <button class="menu-btn" id="menu-open">
            <i class='bx bx-menu'></i>
        </button>
        <h5>Halo <b>JUPRI</b>, Selamat Datang Kembali!</h5>
    </header>

    <div class="separator">
        <div class="info">
            <h3>Kursus Saya</h3>
            <a href="#">Lihat Semua</a>
        </div>
        <div class="search">
            <i class='bx bx-search'></i>
            <input type="text" placeholder="Cari...">
        </div>
    </div>

    <div class="analytics">
        <div class="item">
            <div class="progress">
                <div class="info">
                    <h5>PHP Dasar</h5>
                    <p>11 Sesi</p>
                </div>
                <div class="progress-bar" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
            <span class="akar-icons--php-fill"></span>
        </div>
        <div class="item">
            <div class="progress">
                <div class="info">
                    <h5>PHP Lanjutan</h5>
                    <p>20 Sesi</p>
                </div>
                <div class="progress-bar" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
            <span class="logos--php"></span>
        </div>
        <div class="item">
            <div class="progress">
                <div class="info">
                    <h5>Python</h5>
                    <p>30 Sesi</p>
                </div>
                <div class="progress-bar" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
            <span class="logos--python"></span>
        </div>
        <div class="item">
            <div class="progress">
                <div class="info">
                    <h5>Java Lanjutan</h5>
                    <p>20 Sesi</p>
                </div>
                <div class="progress-bar" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
            <span class="devicon--java"></span>
        </div>
    </div>

    <div class="separator">
        <div class="info">
            <h3>Keranjang</h3>
            <a href="#">Lihat Semua</a>
        </div>
        <input type="date" value="2023-10-15">
    </div>

    <div class="planning">
        <div class="item">
            <div class="left">
                <div class="icon">
                    <span class="devicon--cplusplus"></span>
                </div>
                <div class="details">
                    <h5>C++ Dasar</h5>
                    <p>20 Sesi</p>
                </div>
            </div>
            <i class='bx bx-dots-vertical-rounded'></i>
        </div>
        <div class="item">
            <div class="left">
                <div class="icon">
                    <span class="logos--css-3"></span>
                </div>
                <div class="details">
                    <h5>CSS Styling</h5>
                    <p>20 Sesi</p>
                </div>
            </div>
            <i class='bx bx-dots-vertical-rounded'></i>
        </div>
        <div class="item">
            <div class="left">
                <div class="icon">
                    <span class="logos--html-5"></span>
                </div>
                <div class="details">
                    <h5>HTML 5 Full</h5>
                    <p>30 Sesi</p>
                </div>
            </div>
            <i class='bx bx-dots-vertical-rounded'></i>
        </div>
        <div class="item">
            <div class="left">
                <div class="icon">
                    <span class="devicon--csharp"></span>
                </div>
                <div class="details">
                    <h5>C# Pemula</h5>
                    <p>20 Sesi</p>
                </div>
            </div>
            <i class='bx bx-dots-vertical-rounded'></i>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('right'); ?>
    <div class="top">
        <i class='bx bx-bell'></i>
        <div class="profile">
            <div class="left">
                <img src="assets/images/demo/start-hub-2/img/profile.jpg">
                <div class="user">
                    <h5>Jupri Kawah Ijen</h5>
                    <a href="#">Paket Reguler</a>
                </div>
            </div>
            <i class='bx bxs-chevron-right'></i>
        </div>
    </div>

    <div class="separator" id="first">
        <h4>Statistik</h4>
    </div>

    <div class="stats">
        <div class="item">
            <div class="top">
                <p>Kursus</p>
                <p>Selesai</p>
            </div>
            <div class="bottom">
                <div class="line"></div>
                <h3>02</h3>
            </div>
        </div>
        <div class="item">
            <div class="top">
                <p>Total Point</p>
                <p>Didapatkan</p>
            </div>
            <div class="bottom">
                <div class="line"></div>
                <h3>250</h3>
            </div>
        </div>
        <div class="item">
            <div class="top">
                <p>Kursus</p>
                <p>Dalam Progres</p>
            </div>
            <div class="bottom">
                <div class="line"></div>
                <h3>02</h3>
            </div>
        </div>
        <div class="item">
            <div class="top">
                <p>Tugas</p>
                <p>Selesai</p>
            </div>
            <div class="bottom">
                <div class="line"></div>
                <h3>250</h3>
            </div>
        </div>
    </div>

    <div class="separator">
        <h4>Tugas Mingguan</h4>
    </div>

    <div class="weekly">
        <div class="title">
            <div class="line"></div>
            <h5>Tugas Minggu Ini</h5>
        </div>
        <div class="progress-bar" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel asik cik\landingpage\resources\views/dashboarduser.blade.php ENDPATH**/ ?>