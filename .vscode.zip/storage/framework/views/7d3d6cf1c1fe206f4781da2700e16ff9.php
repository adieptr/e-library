<?php $__env->startSection('main'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/dash.css')); ?>">
<script src="<?php echo e(asset('assets/js/user_script.js')); ?>"></script>
<section class="playlist">

    <h1 class="heading">Detail Materi</h1>

    <div class="row">

       <?php if($playlist): ?>
       <div class="col">
          
          <div class="thumb">
             <?php if($videos): ?>
             <span><?php echo e($videos->count()); ?> Sesi</span>
             <?php endif; ?>
             <img src="<?php echo e(asset('uploaded_files/' . $playlist->thumb)); ?>" alt="">
          </div>
       </div>

       <div class="col">
        <?php if($tutor): ?>
        <div class="tutor">
            <img src="<?php echo e(asset('uploaded_files/' . $tutor->image)); ?>" alt="">
            <div>
                <h3><?php echo e($tutor->name); ?></h3>
                <span><?php echo e($tutor->profession); ?></span>
            </div>
        </div>
        <?php else: ?>
        <div class="tutor">
            <img src="path_to_default_image/default.jpg" alt="">
            <div>
                <h3>Tutor Not Found</h3>
                <span>N/A</span>
            </div>
        </div>
        <?php endif; ?>
          <div class="details">
             <h3><?php echo e($playlist->title); ?></h3>
             <p><?php echo e($playlist->description); ?></p>
             <div class="date"><i class="fas fa-calendar"></i><span><?php echo e($playlist->date); ?></span></div>
          </div>
       </div>

       <?php else: ?>
       <p class="empty">This playlist was not found!</p>
       <?php endif; ?>

    </div>

 </section>

 <!-- playlist section ends -->

 <!-- videos container section starts  -->

 <section class="videos-container">

    <h1 class="heading">Sesi Pembelajaran</h1>

            <div class="box-container">
                <?php if($videos->isNotEmpty()): ?>
                    <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('watch.video', ['id' => $video->id])); ?>" class="box">

                            <i class="fas fa-play"></i>
                            <img src="<?php echo e(asset('uploaded_files/' . $video->thumb)); ?>" alt="">
                            <h3><?php echo e($video->title); ?></h3>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <p class="empty">No videos added yet!</p>
                <?php endif; ?>
            </div>

 </section>

 <!-- videos container section ends -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.userheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel asik cik\codinggo web\resources\views/playlist.blade.php ENDPATH**/ ?>