<?php $__env->startSection('main'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/admin_style.css')); ?>">



<header class="header">

    <section class="flex">

        <a href="<?php echo e(url('/dashboardad')); ?>" class="logo">Tutor</a>



        <div class="icons">
            <div id="menu-btn" class="fas fa-bars"></div>
            <div id="search-btn" class="fas fa-search"></div>
            <div id="user-btn" class="fas fa-user"></div>
            <div id="toggle-btn" class="fas fa-sun"></div>
        </div>

        <div class="profile">

            <img src="<?php echo e(asset('uploaded_files/' . $userImage)); ?>" alt="">
            <h3><?php echo e($userName); ?></h3>
            <span><?php echo e($userProfesi); ?></span>
            <a href="<?php echo e(url('/profileadmin')); ?>" class="btn">view profile</a>

            <a href="<?php echo e(route('logoutad')); ?>" onclick="return confirm('Anda Yakin Ingin Logout?');"
            class="delete-btn">logout</a>

        </div>

    </section>

</header>




<section class="playlist-form">
    <h1 class="heading">Update Kursus</h1>

    <form action="<?php echo e(route('update_playlist')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?> <!-- Tambahkan CSRF token untuk keamanan form -->

        <!-- Input tersembunyi untuk menyimpan ID playlist -->
        <input type="hidden" name="get_id" value="<?php echo e($playlist->id); ?>">

        <p>Status Kursus <span>*</span></p>
        <select name="status" class="box" required>
            <option value="<?php echo e($playlist->status); ?>" selected><?php echo e($playlist->status); ?></option>
            <option value="active">Aktif</option>
            <option value="deactive">Nonaktif</option>
        </select>

        <p>Judul Kursus <span>*</span></p>
        <input type="text" name="title" maxlength="100" required placeholder="Enter playlist title" value="<?php echo e($playlist->title); ?>" class="box">

        <p>Deskripsi Kursus <span>*</span></p>
        <textarea name="description" class="box" required placeholder="Write description" maxlength="1000" cols="30" rows="10"><?php echo e($playlist->description); ?></textarea>

        <p>Unggah Foto Kursus <span>*</span></p>
        <div class="thumb">
            <img src="../uploaded_files/<?php echo e($playlist->thumb); ?>" alt="Playlist Thumbnail">
        </div>
        <input type="file" name="image" accept="image/*" class="box">

        <p>Tingkatan Kursus <span>*</span></p>
        <select name="tingkatan" class="box" required>
           <option value="<?php echo e($playlist->tingkatan); ?>" selected disabled><?php echo e($playlist->tingkatan); ?></option>
           <option value="beginer">Pemula</option>
           <option value="intermiadtel">Menengah</option>
           <option value="advenced">Tingkat Lanjut</option>
        </select>

        <p>Jenis Kursus <span>*</span></p>
        <select name="jenis" class="box" required>
           <option value="<?php echo e($playlist->jenis); ?>" selected disabled><?php echo e($playlist->jenis); ?></option>
           <option value="Pemrograman">Pemrograman</option>
           <option value="Ui/Ux">UI/UX</option>
           <option value="Umum">Lainnya</option>
        </select>

        <p>Harga <span>*</span></p>
        <input type="number" name="harga" maxlength="100" required placeholder="Rp..." value="<?php echo e($playlist->harga); ?>" class="box">

        <input type="submit" value="Update Kursus" name="submit" class="btn">
    </form>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\farai\OneDrive\Dokumen\SMT 4\Project Codinggo\codinggo\codinggo web2\resources\views/update_playlist.blade.php ENDPATH**/ ?>