<?php $__env->startSection('main'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/admin_style.css')); ?>">
    
    <header class="header">

        <section class="flex">

            <a href="<?php echo e(url('/dashboardad')); ?>" class="logo">Tutor</a>

            <form action="<?php echo e(route('caricontentad')); ?>" method="post" class="search-form">
                <?php echo csrf_field(); ?>
                <input type="text" name="search" placeholder="Cari Materi..." required maxlength="100">
                <button type="submit"><i class="fas fa-search"></i></button>
            </form>

            <div class="icons">
                <div id="menu-btn" class="fas fa-bars"></div>
                <div id="search-btn" class="fas fa-search"></div>
                <div id="user-btn" class="fas fa-user"></div>
                <div id="toggle-btn" class="fas fa-sun"></div>
            </div>

            <div class="profile">

                <img src="<?php echo e(asset('uploaded_files/' . $userImage)); ?>" alt="">
                <h3><?php echo e($userName); ?></h3>
                <span><?php echo e($userProfesi); ?></span>
                <a href="<?php echo e(url('/profileadmin')); ?>" class="btn">View Profile</a>

                <a href="<?php echo e(route('logoutad')); ?>" onclick="return confirm('Anda Yakin Ingin Logout?');"
                class="delete-btn">Log out</a>

            </div>

        </section>

    </header>
    <section class="contents">

        <h1 class="heading">Materi Anda</h1>

        <?php if(session('success')): ?>
        <div class="modal-box" id="success-message">
            <i class="fa-solid fa-check-to-slot"></i>
            <h2>Success</h2>
            <h3><?php echo e(session('success')); ?></h3>
            <div class="but">
                <button class="tutupbut" onclick="closeModalAndClearSession()">OK</button>
            </div>
        </div>
        <?php elseif(session('error')): ?>
            <div id="error-message" class="popup-message"><?php echo e(session('error')); ?></div>
        <?php endif; ?>


        <?php if(session('sucesup')): ?>
        <div class="modal-up" id="success-message">
            <i class="fa-solid fa-thumbs-up"></i>
            <h2>Success</h2>
            <h3><?php echo e(session('sucesup')); ?></h3>
            <div class="butup">
                <button class="tutupbutup" onclick="closeModalAndClearSession()">OK</button>
            </div>
        </div>
        <?php elseif(session('errorup')): ?>
            <div id="error-message" class="popup-message"><?php echo e(session('error')); ?></div>
        <?php endif; ?>


        <div class="box-container">

            <div class="box" style="text-align: center;">
                <h3 class="title" style="margin-bottom: .5rem;">Buat Materi Baru</h3>
                <a href="<?php echo e(route('add_content')); ?>" class="btn">Tambah</a>
            </div>

            <?php if(count($contents) > 0): ?>
                <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="box">
                        <div class="flex">
                            <div><i class="fas fa-dot-circle"
                                    style="<?php echo e($content->status == 'active' ? 'color:limegreen' : 'color:red'); ?>"></i><span
                                    style="<?php echo e($content->status == 'active' ? 'color:limegreen' : 'color:red'); ?>"><?php echo e($content->status); ?></span>
                            </div>
                            <div><i class="fas fa-calendar"></i><span><?php echo e($content->date); ?></span></div>
                        </div>
                        <img src="../uploaded_files/<?php echo e($content->thumb); ?>" class="thumb" alt="">
                        <h3 class="title"><?php echo e($content->title); ?></h3>
                        <form action="<?php echo e(route('delete_video')); ?>" method="post" class="flex-btn">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="video_id" value="<?php echo e($content->id); ?>">
                            <a href="<?php echo e(route('update.content', ['videoId' => $content->id])); ?>"
                                class="option-btn">Ubah</a>

                            <button type="submit" class="delete-btn"
                                onclick="return confirm('Hapus materi ini?');">Hapus</button>
                        </form>
                        <a href="<?php echo e(route('watchad.video', ['id' => $content->id])); ?>" class="btn">Lihat Materi</a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <p class="empty">Tidak ada materi yang ditambahkan!</p>
            <?php endif; ?>

        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\farai\OneDrive\Dokumen\SMT 4\Project Codinggo\codinggo\codinggo web2\resources\views/contentad.blade.php ENDPATH**/ ?>