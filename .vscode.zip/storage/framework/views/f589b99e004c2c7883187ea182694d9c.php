<?php $__env->startSection('main'); ?>
    <header class="header">

        <section class="flex">

            <a href="<?php echo e(url('/dashboardad')); ?>" class="logo">Tutor</a>

            <form action="<?php echo e(route('pages.carisiswaad')); ?>" method="post" class="search-form">
                <?php echo csrf_field(); ?>
                <input type="text" name="keyword" placeholder="Cari Siswa..." required maxlength="100">
                <button type="submit" class="fas fa-search" name="search_btn"></button>
            </form>

            <div class="icons">
                <div id="menu-btn" class="fas fa-bars"></div>
                <div id="search-btn" class="fas fa-search"></div>
                <div id="user-btn" class="fas fa-user"></div>
                <div id="toggle-btn" class="fas fa-sun"></div>
            </div>

            <div class="profile">

                <img src="<?php echo e(asset('uploaded_files/' . $userImage)); ?>" alt="">
                <h3><?php echo e($userName); ?></h3>
                <span><?php echo e($userProfesi); ?></span>
                <a href="<?php echo e(url('/profileadmin')); ?>" class="btn">View Profile</a>

                <a href="<?php echo e(route('logoutad')); ?>" onclick="return confirm('Anda Yakin Ingin Lo gout?');"
                class="delete-btn">Log out</a>

            </div>

        </section>

    </header>


    <section class="dashboard">



        <div class="content">

            <main>
                

                <!-- Insights -->
                <ul class="insights">
                    <a href="<?php echo e(route('coursesad.index')); ?>">
                        <li>
                            <i class='bx bx-book-open'></i>
                            <span class="info">
                                <h3>
                                    <?php echo e($totalPlaylists); ?>

                                </h3>
                                <p>Total Kursus</p>
                            </span>
                        </li>
                    </a>

                    <a href="<?php echo e(route('contentad.index')); ?>">
                        <li><i class='bx bx-copy-alt'></i>
                            <span class="info">
                                <h3>
                                    <?php echo e($totalContents); ?>

                                </h3>
                                <p>Total Materi</p>
                            </span>
                        </li>
                    </a>

                    <a href="<?php echo e(route('commentsad')); ?>">
                        <li><i class='bx bx-comment-detail'></i>
                            <span class="info">
                                <h3>
                                    <?php echo e($totalComments); ?>

                                </h3>
                                <p>Total Komentar</p>
                            </span>
                        </li>
                    </a>

                    <a href="">
                        <li><i class='bx bx-user'></i>
                            <span class="info">
                                <h3>
                                    <?php echo e($totalUsers); ?>

                                </h3>
                                <p>Total Siswa</p>
                            </span>
                        </li>
                    </a>
                </ul>
                <!-- End of Insights -->

                <div class="bottom-data">
                    <div class="orders">
                        <div class="header2">
                            <i class='bx bx-receipt'></i>
                            <h3>Data Siswa</h3>
                        </div>
                        <table>
                            <thead>
                                <tr>
                                    <th>Siswa</th>
                                    <th>Email</th>
                                    <th>Kursus</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <img src="<?php echo e(asset('uploaded_files/' . $item->image)); ?>" alt="">
                                            <p style="font-size: 20px"><?php echo e($item->name); ?></p>
                                        </td>
                                        <td>
                                            <p style="font-size: 20px"><?php echo e($item->email); ?></p>
                                        </td>
                                        <td style="font-size: 20px">
                                            <?php if(isset($item->playlist) && isset($item->playlist->title)): ?>
                                                <?php echo e($item->playlist->title); ?>

                                            <?php else: ?>
                                                Nama Kursus Tidak Tersedia
                                            <?php endif; ?>
                                        </td>
                                        
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                </div>

            </main>

        </div>




    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\farai\OneDrive\Dokumen\SMT 4\Project Codinggo\codinggo web2\resources\views/dashboardad.blade.php ENDPATH**/ ?>