<?php $__env->startSection('main'); ?>


<header class="header">

    <section class="flex">

        <a href="<?php echo e(url('/dashboardad')); ?>" class="logo">Tutor</a>

        <form action="<?php echo e(route('playlist.search', $playlist->id)); ?>" method="post" class="search-form">
            <?php echo csrf_field(); ?> <!-- Tambahkan CSRF token untuk menjaga keamanan -->
            <input type="text" name="search" placeholder="Cari Content..." required maxlength="100">
            <button type="submit" class="fas fa-search" name="search_btn"></button>
        </form>


        <div class="icons">
            <div id="menu-btn" class="fas fa-bars"></div>
            <div id="search-btn" class="fas fa-search"></div>
            <div id="user-btn" class="fas fa-user"></div>
            <div id="toggle-btn" class="fas fa-sun"></div>
        </div>

        <div class="profile">

            <img src="<?php echo e(asset('uploaded_files/' . $userImage)); ?>" alt="">
            <h3><?php echo e($userName); ?></h3>
            <span><?php echo e($userProfesi); ?></span>
            <a href="<?php echo e(url('/profileadmin')); ?>" class="btn">View Profile</a>

            <a href="<?php echo e(route('logoutad')); ?>" onclick="return confirm('Anda Yakin Ingin Logout?');"
            class="delete-btn">Log out</a>

        </div>

    </section>

</header>

<section class="playlist-details">

    <h1 class="heading">Detail Kursus</h1>

    <div class="row">

       <?php if($playlist): ?>
          <div class="thumb">
             <?php if($videos): ?>
             <span><?php echo e($videos->count()); ?> Materi</span>
             <?php endif; ?>
             <img src="<?php echo e(asset('uploaded_files/' . $playlist->thumb)); ?>" alt="">
          </div>


       <div class="col">
        
        
        
          <div class="details">
             <h3 class="title"><?php echo e($playlist->title); ?></h3>
             <div class="description"><?php echo e($playlist->description); ?></div>
             <div class="date"><i class="fas fa-calendar"></i><span><?php echo e($playlist->date); ?></span></div>

             <form action="<?php echo e(route('delete_playlist')); ?>" method="post" class="flex-btn">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="playlist_id" value="<?php echo e($playlist->id); ?>">
                <a href="<?php echo e(route('update_playlist_view', ['get_id' => $playlist->id])); ?>" class="option-btn">Ubah<a>
                <input type="submit" value="Hapus" class="delete-btn" onclick="return confirm('Anda Yakin Ingin Menghapus Kursus?');" name="delete">
             </form>
          </div>
       </div>

       <?php else: ?>
       <p class="empty">Kursus tidak ditemukan!</p>
       <?php endif; ?>

    </div>
</section>

 <!-- playlist section ends -->

 <!-- videos container section starts  -->

 <section class="contents">

    <h1 class="heading">Materi Pembelajaran</h1>

            <div class="box-container">
                <?php if($videos->isNotEmpty()): ?>
                    <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="box">
                        <div class="flex">
                           <div><i class="fas fa-dot-circle" style="<?php echo e($video->status == 'active' ? 'color:limegreen' : 'color:red'); ?>"></i><span style="<?php echo e($video->status == 'active' ? 'color:limegreen' : 'color:red'); ?>"><?php echo e($video->status); ?></span></div>
                           <div><i class="fas fa-calendar"></i><span><?php echo e($video->date); ?></span></div>
                        </div>
                        <img src="../uploaded_files/<?php echo e($video->thumb); ?>" class="thumb" alt="">
                        <h3 class="title"><?php echo e($video->title); ?></h3>
                        <form action="<?php echo e(route('delete_video')); ?>" method="post" class="flex-btn">
                           <?php echo csrf_field(); ?>
                           <input type="hidden" name="video_id" value="<?php echo e($video->id); ?>">
                           <a href="<?php echo e(route('update.content', ['videoId' => $video->id])); ?>" class="option-btn">Ubah</a>

                           <button type="submit" class="delete-btn" onclick="return confirm('Delete this video?');">Hapus</button>
                        </form>
                        <a href="<?php echo e(route('watchad.video', ['id' => $video->id])); ?>" class="btn">Lihat Materi</a>
                     </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <p class="empty">Tidak ada materi yang ditambahkan!</p>
                <?php endif; ?>
            </div>

 </section>

 <!-- videos container section ends -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\farai\OneDrive\Dokumen\SMT 4\Project Codinggo\codinggo web2\resources\views/playlistad.blade.php ENDPATH**/ ?>