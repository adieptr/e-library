<?php $__env->startSection('main'); ?>
    <div class="header">
        <div class="left">
            <h1>Dashboard</h1>
            <ul class="breadcrumb">
                
            </ul>
        </div>
        
    </div>

    <!-- Insights -->
    <ul class="insights">
        <li>
            <i class='bx bx-calendar-check'></i>
            <span class="info">
                <h3>
                    1,074
                </h3>
                <p>Total Kursus</p>
            </span>
        </li>
        <li><i class='bx bx-user-circle'></i>
            <span class="info">
                <h3>
                    3,944
                </h3>
                <p>Total Siswa</p>
            </span>
        </li>
        <li><i class='bx bx-line-chart'></i>
            <span class="info">
                <h3>
                    4,721
                </h3>
                <p>Pencarian</p>
            </span>
        </li>
        <li><i class='bx bx-dollar-circle'></i>
            <span class="info">
                <h3>
                    Rp.2,000,000,000
                </h3>
                <p>Pendapatan</p>
            </span>
        </li>
    </ul>
    <!-- End of Insights -->

    <div class="bottom-data">
        <div class="orders">
            <div class="header">
                <i class='bx bx-receipt'></i>
                <h3>Transaksi Terbaru</h3>
                <i class='bx bx-filter'></i>
                <i class='bx bx-search'></i>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Siswa</th>
                        <th>Tanggal</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            <img src="assets/images/demo/start-hub-2/img/profile.jpg">
                            <p>Holili Baut Onderdil</p>
                        </td>
                        <td>14-08-2023</td>
                        <td><span class="status completed">Selesai</span></td>
                    </tr>
                    <tr>
                        <td>
                            <img src="assets/images/demo/start-hub-2/img/profile.jpg">
                            <p>Roni Las Karbit</p>
                        </td>
                        <td>14-08-2023</td>
                        <td><span class="status pending">Ditunda</span></td>
                    </tr>
                    <tr>
                        <td>
                            <img src="assets/images/demo/start-hub-2/img/profile.jpg">
                            <p>Kiki Cakram Kopling </p>
                        </td>
                        <td>14-08-2023</td>
                        <td><span class="status process">Proses</span></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- Reminders -->
        <div class="reminders">
            <div class="header">
                <i class='bx bx-note'></i>
                <h3>Pengingat</h3>
                <i class='bx bx-filter'></i>
                <i class='bx bx-plus'></i>
            </div>
            <ul class="task-list">
                <li class="completed">
                    <div class="task-title">
                        <i class='bx bx-check-circle'></i>
                        <p>Meeting Dengan Pengajar</p>
                    </div>
                    <i class='bx bx-dots-vertical-rounded'></i>
                </li>
                <li class="completed">
                    <div class="task-title">
                        <i class='bx bx-check-circle'></i>
                        <p>Analisa Aplikasi Mobile</p>
                    </div>
                    <i class='bx bx-dots-vertical-rounded'></i>
                </li>
                <li class="not-completed">
                    <div class="task-title">
                        <i class='bx bx-x-circle'></i>
                        <p>Cek SEO Website</p>
                    </div>
                    <i class='bx bx-dots-vertical-rounded'></i>
                </li>
            </ul>
        </div>

        <!-- End of Reminders-->

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('sidebarad', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel asik cik\landingpage\resources\views/dashboardad.blade.php ENDPATH**/ ?>