<?php $__env->startSection('main'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/admin_style.css')); ?>">




<header class="header">

    <section class="flex">

        <a href="<?php echo e(url('/dashboardad')); ?>" class="logo">Tutor</a>



        <div class="icons">
            <div id="menu-btn" class="fas fa-bars"></div>
            <div id="search-btn" class="fas fa-search"></div>
            <div id="user-btn" class="fas fa-user"></div>
            <div id="toggle-btn" class="fas fa-sun"></div>
        </div>

        <div class="profile">

            <img src="<?php echo e(asset('uploaded_files/' . $userImage)); ?>" alt="">
            <h3><?php echo e($userName); ?></h3>
            <span><?php echo e($userProfesi); ?></span>
            <a href="<?php echo e(url('/profileadmin')); ?>" class="btn">View Profile</a>

            <a href="<?php echo e(route('logoutad')); ?>" onclick="return confirm('Anda Yakin Ingin Logout?');"
            class="delete-btn">Log out</a>
        </div>

    </section>

</header>





<section class="form-container" style="min-height: calc(100vh - 19rem);">

    <form action="<?php echo e(route('tutors.update', $tutor->id)); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
       <h3>Update Profile</h3>
       <<div class="flex">
        <div class="col">
           <p>Nama Anda :</p>
           <input type="text" name="name" placeholder="<?php echo e($tutor->name); ?>" maxlength="100"  class="box">
           <p>Email Anda :</p>
           <input type="email" name="email" placeholder="<?php echo e($tutor->email); ?>" maxlength="100"  class="box">
           <p>Profesi Anda :</p>
           <input type="profession" name="profession" placeholder="<?php echo e($tutor->profession); ?>" maxlength="100"  class="box">
        </div>
        <div class="col">
           <p>Password Baru :</p>
           <input type="password" name="old_pass" placeholder="enter your old password" maxlength="20"  class="box">
           <p>Password Baru :</p>
           <input type="password" name="new_pass" placeholder="enter your new password" maxlength="20"  class="box">
           <p>Konfirmasi Password :</p>
           <input type="password" name="cpass" placeholder="confirm your new password" maxlength="20"  class="box">
        </div>
     </div>
     <p>Unggah Foto Profil</p>
     <input type="file" name="image" accept="image/*"  class="box">
     <input type="submit" name="submit" value="update" class="btn">
    </form>

 </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\farai\OneDrive\Dokumen\SMT 4\Project Codinggo\codinggo\codinggo web2\resources\views/updateprofilea.blade.php ENDPATH**/ ?>