<?php $__env->startSection('main'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/admin_style.css')); ?>">




<header class="header">

    <section class="flex">

        <a href="<?php echo e(url('/dashboardad')); ?>" class="logo">Tutor.</a>



        <div class="icons">
            <div id="menu-btn" class="fas fa-bars"></div>
            <div id="search-btn" class="fas fa-search"></div>
            <div id="user-btn" class="fas fa-user"></div>
            <div id="toggle-btn" class="fas fa-sun"></div>
        </div>

        <div class="profile">

            <img src="<?php echo e(asset('uploaded_files/' . $userImage)); ?>" alt="">
            <h3><?php echo e($userName); ?></h3>
            <span><?php echo e($userProfesi); ?></span>
            <a href="<?php echo e(url('/profileadmin')); ?>" class="btn">view profile</a>

            <a href="<?php echo e(route('logoutad')); ?>" onclick="return confirm('Anda Yakin Ingin Logout?');"
            class="delete-btn">logout</a>
        </div>

    </section>

</header>





<section class="form-container" style="min-height: calc(100vh - 19rem);">

    <form action="<?php echo e(route('tutors.update', $tutor->id)); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
       <h3>update profile</h3>
       <<div class="flex">
        <div class="col">
           <p>your name </p>
           <input type="text" name="name" placeholder="<?php echo e($tutor->name); ?>" maxlength="100"  class="box">
           <p>your profession </p>
           <select name="profession" class="box">
              <option value="" selected><?php echo e($tutor->profession); ?></option>
              <option value="developer">developer</option>
              <option value="desginer">desginer</option>
              <option value="musician">musician</option>
              <option value="biologist">biologist</option>
              <option value="teacher">teacher</option>
              <option value="engineer">engineer</option>
              <option value="lawyer">lawyer</option>
              <option value="accountant">accountant</option>
              <option value="doctor">doctor</option>
              <option value="journalist">journalist</option>
              <option value="photographer">photographer</option>
           </select>
           <p>your email </p>
           <input type="email" name="email" placeholder="<?php echo e($tutor->email); ?>" maxlength="100"  class="box">
        </div>
        <div class="col">
           <p>old password :</p>
           <input type="password" name="old_pass" placeholder="enter your old password" maxlength="20"  class="box">
           <p>new password :</p>
           <input type="password" name="new_pass" placeholder="enter your new password" maxlength="20"  class="box">
           <p>confirm password :</p>
           <input type="password" name="cpass" placeholder="confirm your new password" maxlength="20"  class="box">
        </div>
     </div>
     <p>update pic :</p>
     <input type="file" name="image" accept="image/*"  class="box">
     <input type="submit" name="submit" value="update now" class="btn">
    </form>

 </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel asik cik\codinggo web2\resources\views/updateprofilea.blade.php ENDPATH**/ ?>