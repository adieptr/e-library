<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tutor (<?php echo e($userName); ?>)</title>

    <!-- Font Awesome CDN link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

    <!-- Custom CSS file link -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/admin_style.css')); ?>">
    <link rel="icon" href="<?php echo e(asset('assets/images/demo/start-hub-2/logo/sidelogo.png')); ?>">
</head>

<body>
    

    <!-- header section ends -->

    <!-- side bar section starts  -->

    <div class="side-bar">

        <div class="close-side-bar">
            <i class="fas fa-times"></i>
        </div>

        <div class="profile">

            <img src="<?php echo e(asset('uploaded_files/' . $userImage)); ?>" alt="">
            <h3><?php echo e($userName); ?></h3>
            <span><?php echo e($userProfesi); ?></span>
            <a href="<?php echo e(url('/profileadmin')); ?>" class="btn">View Profile</a>

        </div>

        <nav class="navbar">
            <a href="<?php echo e(url('/dashboardad')); ?>"><i class="fas fa-home"></i><span>Beranda</span></a>
            <a href="<?php echo e(route('coursesad.index')); ?>"><i class="fa-solid fa-bars-staggered"></i><span>Kursus</span></a>
            <a href="<?php echo e(route('contentad.index')); ?>"><i class="fas fa-graduation-cap"></i><span>Materi</span></a>
            <a href="<?php echo e(route('commentsad')); ?>"><i class="fas fa-comment"></i><span>Komentar</span></a>
            <a href="<?php echo e(route('logoutad')); ?>" onclick="return confirm('Anda Yakin Ingin Log out?');"><i
                    class="fas fa-right-from-bracket"></i><span>Log out</span></a>

        </nav>

    </div>

    <!-- side bar section ends -->
    <main>
        <?php echo $__env->yieldContent('main'); ?>
    </main>
    <script src="<?php echo e(asset('assets/js/admin_script.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\Users\farai\OneDrive\Dokumen\SMT 4\Project Codinggo\codinggo web2\resources\views/components/adminheader.blade.php ENDPATH**/ ?>