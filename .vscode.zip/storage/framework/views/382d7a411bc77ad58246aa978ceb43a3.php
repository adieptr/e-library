<?php $__env->startSection('main'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/admin_style.css')); ?>">


<header class="header">

    <section class="flex">

        <a href="<?php echo e(url('/dashboardsp')); ?>" class="logo">Admin.</a>

        <form action="<?php echo e(route('siswa.carisiswa')); ?>" method="post" class="search-form">
            <?php echo csrf_field(); ?>
            <input type="text" name="search" placeholder="Cari Siswa..." required maxlength="100">
            <button type="submit" class="fas fa-search" name="search_btn"></button>
        </form>

        <div class="icons">
            <div id="menu-btn" class="fas fa-bars"></div>
            <div id="search-btn" class="fas fa-search"></div>
            <div id="user-btn" class="fas fa-user"></div>
            <div id="toggle-btn" class="fas fa-sun"></div>
        </div>

        <div class="profile">

            <img src="<?php echo e(asset('uploaded_files/' . $userImage)); ?>" alt="">
            <h3><?php echo e($userName); ?></h3>
            <span><?php echo e($userProfesi); ?></span>
            <a href="<?php echo e(url('/profilesp')); ?>" class="btn">view profile</a>

            <a href="../components/admin_logout.php" onclick="return confirm('logout from this website?');"
                class="delete-btn">logout</a>

        </div>

    </section>

</header>

<section class="contents">

    <h1 class="heading">Siswa</h1>

    <div class="box-container">
    <?php if(count($contents) > 0): ?>
       <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="box">
             <div class="flex">
             </div>
             <img src="../uploaded_files/<?php echo e($content->image); ?>" class="thumb" alt="">
             <h3 class="title"><?php echo e($content->name); ?></h3>
             <h4 class="title"><?php echo e($content->email); ?></h3>

          </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
       <p class="empty">No contents added yet!</p>
    <?php endif; ?>

    </div>

 </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.spheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel asik cik\codinggo web\resources\views/viewsiswa.blade.php ENDPATH**/ ?>