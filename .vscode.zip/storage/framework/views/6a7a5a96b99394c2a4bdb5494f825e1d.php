<?php $__env->startSection('main'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/admin_style.css')); ?>">



<header class="header">

    <section class="flex">

        <a href="<?php echo e(url('/dashboardad')); ?>" class="logo">Tutor.</a>

        

        <div class="icons">
            <div id="menu-btn" class="fas fa-bars"></div>
            <div id="search-btn" class="fas fa-search"></div>
            <div id="user-btn" class="fas fa-user"></div>
            <div id="toggle-btn" class="fas fa-sun"></div>
        </div>

        <div class="profile">

            <img src="<?php echo e(asset('uploaded_files/' . $userImage)); ?>" alt="">
            <h3><?php echo e($userName); ?></h3>
            <span><?php echo e($userProfesi); ?></span>
            <a href="<?php echo e(url('/profileadmin')); ?>" class="btn">view profile</a>

            <a href="<?php echo e(route('logoutad')); ?>" onclick="return confirm('Anda Yakin Ingin Logout?');"
            class="delete-btn">logout</a>

        </div>

    </section>

</header>



    <section class="view-content">

        <?php if($video): ?>
            <div class="container">
                <video src="<?php echo e(asset('uploaded_files/' . $video->video)); ?>" class="video" poster="<?php echo e(asset('uploaded_files/' . $video->thumb)); ?>" controls autoplay></video>

                <h3 class="title"><?php echo e($video->title); ?></h3>
                <div class="date">
                    <p><i class="fas fa-calendar"></i><span><?php echo e($video->date); ?></span></p>
                </div>
                
                

                <div class="description"><p><?php echo e($video->description); ?></p></div>
                <form action="<?php echo e(route('delete_video')); ?>" method="post">
                    <div class="flex-btn">
                        <?php echo csrf_field(); ?>
                       <input type="hidden" name="video_id" value="<?php echo e($video->id); ?>">
                       <a href="<?php echo e(route('update.content', ['videoId' => $video->id])); ?>" class="option-btn">update</a>
                       <input type="submit" value="delete" class="delete-btn" onclick="return confirm('delete this video?');" name="delete_video">
                    </div>
                 </form>
            </div>
        <?php else: ?>
            <p class="empty">No videos added yet!</p>
        <?php endif; ?>

    </section>

    <section class="comments">

        

        <div class="show-comments">
            <?php if($comments->count() > 0): ?>
            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="box" style="<?php echo e($comment->tutor_id == $userId ? 'order:-1;' : ''); ?>">
                <?php
                    $user = $users->where('id', $comment->user_id)->first();
                ?>
                <?php if($user): ?>
                  <div class="user">
                    <img src="<?php echo e(asset('uploaded_files/' . $user->image)); ?>" alt="">
                    <div>
                        <h3><?php echo e($user->name); ?></h3>
                        <span><?php echo e($comment->date); ?></span>

                    </div>
                      
                  </div>
                <?php endif; ?>
                  <p class="text"><?php echo e($comment->comment); ?></p>
                  <!-- Tampilkan nama pengguna -->
                  
                  <form action="<?php echo e(route('delete.comment')); ?>" method="post">
                     <?php echo csrf_field(); ?>
                     <input type="hidden" name="comment_id" value="<?php echo e($comment->id); ?>">
                     <button type="submit" name="delete_comment" class="inline-delete-btn" onclick="return confirm('Delete this comment?');">Delete Comment</button>
                  </form>
               </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php else: ?>
            <p class="empty">No comments added yet!</p>
         <?php endif; ?>
        </div>


    </section>

    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\farai\OneDrive\Dokumen\SMT 4\Project Codinggo\codinggo\codinggo web2\resources\views/watch_videoad.blade.php ENDPATH**/ ?>