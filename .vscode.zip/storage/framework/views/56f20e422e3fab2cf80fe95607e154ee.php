<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="assets/css/loginregis.css" />
    <script src="https://smtpjs.com/v3/smtp.js"></script>
    <title>Verifikasi</title>
</head>
<?php if(session('success')): ?>

<?php elseif(session('error')): ?>
    <div class="modal-sal" id="gagal-message">
        <i class="fa-solid fa-circle-exclamation"></i>
        <h2>Gagal</h2>
        <h3><?php echo e(session('error')); ?></h3>
        <div class="butsal">
            <button class="tutupsal" onclick="closeModalAndClearSession()">OK</button>
        </div>
    </div>
<?php endif; ?>


<body>
    <script src="lupas.js"></script>
    <div class="container">
        <div class="forms-container">
            <div class="signin-signup">
                <form action="<?php echo e(route('updatePassword')); ?>" class="sign-in-form" method="POST">
                    <?php echo csrf_field(); ?>
                    <h2 class="title">Update Password</h2>

                    <?php if(isset($message)): ?>
                        <div class="message form">
                            <span><?php echo e($message); ?></span>
                            <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
                        </div>
                    <?php endif; ?>

                        <div class="input-field">
                            <i class="fas fa-user"></i>
                            <input type="email" placeholder="Email" name="email" required id="email" />
                        </div>
                        <div class="input-field">
                            <i class="fas fa-user"></i>
                            <input type="password" name="password" required placeholder="Password" />
                        </div>
                        <button type="submit" class="btn solid">Ubah</button>
                </form>







                

            </div>
        </div>

        <div class="panels-container">
            <div class="panel left-panel">
                <div class="content">
                    <h3>Update Password Baru</h3>
                    <p>
                        Masukkan Email Yang sama dengan Email yang Kamu Gunakan Untuk Verifikasi Tadi, Isi Password Form Lalu Klik Kirim
                    </p>
                </div>
                <img src="img/log.svg" class="image" alt="" />
            </div>
            
        </div>
    </div>

    <script src="assets/js/app.js"></script>
    <script src="assets/js/script.js"></script>
</body>

</html>
<?php /**PATH C:\laravel asik cik\codinggo web\resources\views/updatepass.blade.php ENDPATH**/ ?>