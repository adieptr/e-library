<?php $__env->startSection('main'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/admin_style.css')); ?>">


<header class="header">

    <section class="flex">

        <a href="<?php echo e(url('/dashboardsp')); ?>" class="logo">Admin.</a>

        <form action="<?php echo e(route('siswa.carisiswa')); ?>" method="post" class="search-form">
            <?php echo csrf_field(); ?>
            <input type="text" name="search" placeholder="Cari Siswa..." required maxlength="100">
            <button type="submit" class="fas fa-search" name="search_btn"></button>
        </form>

        <div class="icons">
            <div id="menu-btn" class="fas fa-bars"></div>
            <div id="search-btn" class="fas fa-search"></div>
            <div id="user-btn" class="fas fa-user"></div>
            <div id="toggle-btn" class="fas fa-sun"></div>
        </div>

        <div class="profile">

            <img src="<?php echo e(asset('uploaded_files/' . $userImage)); ?>" alt="">
            <h3><?php echo e($userName); ?></h3>
            <span><?php echo e($userProfesi); ?></span>
            <a href="<?php echo e(url('/profilesp')); ?>" class="btn">View Profile</a>

            <a href="<?php echo e(route('logoutsp')); ?>" onclick="return confirm('Anda Yakin Ingin Logout?');"
                class="delete-btn">logout</a>
        </div>

    </section>

</header>

<section class="contents">

    <h1 class="heading">Student</h1>

    <div class="box-container">
    <?php if(count($contents) > 0): ?>
       <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="box">
             <div class="flex">
             </div>
             <img src="../uploaded_files/<?php echo e($content->image); ?>" class="thumb" alt="">
             <h3 class="title"><?php echo e($content->name); ?></h3>
             <h4 class="title"><?php echo e($content->email); ?></h3>

          </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
       <p class="empty">No contents added yet!</p>
    <?php endif; ?>

    </div>

    <div class="page">
        <div class="pagination">
            <ul> <!-- pages or li are comes from javascript --> </ul>
        </div>

 </section>
 <script>
    function closeModalAndClearSession() {
        document.getElementById('success-message').style.display = 'none';
        // Tambahkan kode untuk menghapus sesi jika diperlukan
    }

    const element = document.querySelector(".pagination ul");
    const totalPages = <?php echo e($totalPages); ?>;
    const currentPage = <?php echo e($currentPage); ?>;

    element.innerHTML = createPagination(totalPages, currentPage);

    function createPagination(totalPages, page) {
        let liTag = '';
        let active;
        let beforePage = page - 1;
        let afterPage = page + 1;
        if (page > 1) {
            liTag += `<li class="newbtn prev" onclick="changePage(${page - 1})"><span><i class="fas fa-angle-left"></i> Prev</span></li>`;
        }

        if (page > 2) {
            liTag += `<li class="first numb" onclick="changePage(1)"><span>1</span></li>`;
            if (page > 3) {
                liTag += `<li class="dots"><span>...</span></li>`;
            }
        }

        // if (page == totalPages) {
        //     beforePage = beforePage - 2;
        // } else if (page == totalPages - 1) {
        //     beforePage = beforePage - 1;
        // }
        if (page == 1) {
            afterPage = afterPage + 2;
        } else if (page == 2) {
            afterPage = afterPage + 1;
        }

        for (var plength = beforePage; plength <= afterPage; plength++) {
            if (plength > totalPages) {
                continue;
            }
            if (plength == 0) {
                plength = plength + 1;
            }
            if (page == plength) {
                active = "active";
            } else {
                active = "";
            }
            liTag += `<li class="numb ${active}" onclick="changePage(${plength})"><span>${plength}</span></li>`;
        }

        if (page < totalPages - 1) {
            if (page < totalPages - 2) {
                liTag += `<li class="dots"><span>...</span></li>`;
            }
            liTag += `<li class="last numb" onclick="changePage(${totalPages})"><span>${totalPages}</span></li>`;
        }

        if (page < totalPages) {
            liTag += `<li class="newbtn next" onclick="changePage(${page + 1})"><span>Next <i class="fas fa-angle-right"></i></span></li>`;
        }
        element.innerHTML = liTag;
        return liTag;
    }

    function changePage(page) {
        const url = new URL(window.location.href);
        url.searchParams.set('page', page);
        window.location.href = url.toString();
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.spheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\farai\OneDrive\Dokumen\SMT 4\Project Codinggo\codinggo web2\resources\views/viewsiswa.blade.php ENDPATH**/ ?>