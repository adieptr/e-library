<?php $__env->startSection('main'); ?>
<link rel="stylesheet" href="assets/css/admin_style.css">


<header class="header">

    <section class="flex">

        <a href="<?php echo e(url('/dashboardad')); ?>" class="logo">Tutor.</a>



        <div class="icons">
            <div id="menu-btn" class="fas fa-bars"></div>
            <div id="search-btn" class="fas fa-search"></div>
            <div id="user-btn" class="fas fa-user"></div>
            <div id="toggle-btn" class="fas fa-sun"></div>
        </div>

        <div class="profile">

            <img src="<?php echo e(asset('uploaded_files/' . $userImage)); ?>" alt="">
            <h3><?php echo e($userName); ?></h3>
            <span><?php echo e($userProfesi); ?></span>
            <a href="<?php echo e(url('/profileadmin')); ?>" class="btn">view profile</a>

            <a href="<?php echo e(route('logoutad')); ?>" onclick="return confirm('Anda Yakin Ingin Logout?');"
            class="delete-btn">logout</a>

        </div>

    </section>

</header>


<section class="tutor-profile" style="min-height: calc(100vh - 19rem);">


    <h1 class="heading">profile details</h1>

    <?php if(session('success')): ?>
    <div class="modal-box" id="success-message">
        <i class="fa-solid fa-check-to-slot"></i>
        <h2>Success</h2>
        <h3><?php echo e(session('success')); ?></h3>
        <div class="but">
            <button class="tutupbut" onclick="closeModalAndClearSession()">OK</button>
        </div>
    </div>
    <?php elseif(session('error')): ?>
        <div id="error-message" class="popup-message"><?php echo e(session('error')); ?></div>
    <?php endif; ?>


    <?php if(session('sucesup')): ?>
    <div class="modal-up" id="success-message">
        <i class="fa-solid fa-thumbs-up"></i>
        <h2>Success</h2>
        <h3><?php echo e(session('sucesup')); ?></h3>
        <div class="butup">
            <button class="tutupbutup" onclick="closeModalAndClearSession()">OK</button>
        </div>
    </div>
    <?php elseif(session('errorup')): ?>
        <div id="error-message" class="popup-message"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <div class="details">

       <div class="tutor">
        <img src="<?php echo e(asset('uploaded_files/' . $userImage)); ?>" alt="">
        <h3><?php echo e($userName); ?></h3>
        <span><?php echo e($userProfesi); ?></span>
        <a href="<?php echo e(route('tutors.edit', $tutorsId)); ?>" class="inline-btn">update profile</a>
       </div>

       <div class="flex">
        <div class="box">
           <span><?php echo e($totalPlaylists); ?></span>
           <p>Total Materi</p>
           <a href="<?php echo e(route('coursesad.index')); ?>" class="btn">view Materi</a>
        </div>
        <div class="box">
           <span><?php echo e($totalContents); ?></span>
           <p>Total Contents</p>
           <a href="<?php echo e(route('contentad.index')); ?>" class="btn">view contents</a>
        </div>
        <div class="box">
           <span><?php echo e($totalUsers); ?></span>
           <p>Total Siswa</p>
           <a href="<?php echo e(url('/dashboardad')); ?>" class="btn">view dashboard</a>
        </div>
        <div class="box">
           <span> <?php echo e($totalComments); ?></span>
           <p>Total Comments</p>
           <a href="<?php echo e(route('commentsad')); ?>" class="btn">view comments</a>
        </div>
     </div>

    </div>

 </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel asik cik\codinggo web2\resources\views/profileadmin.blade.php ENDPATH**/ ?>