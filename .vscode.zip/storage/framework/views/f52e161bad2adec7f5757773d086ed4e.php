<?php $__env->startSection('main'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/admin_style.css')); ?>">


<header class="header">
    <section class="flex">
        <a href="<?php echo e(url('/dashboardad')); ?>" class="logo">Tutor</a>

        <form action="<?php echo e(route('caricontentad')); ?>" method="post" class="search-form">
            <?php echo csrf_field(); ?>
            <input type="text" name="search" placeholder="Cari Materi..." required maxlength="100">
            <button type="submit"><i class="fas fa-search"></i></button>
        </form>

        <div class="icons">
            <div id="menu-btn" class="fas fa-bars"></div>
            <div id="search-btn" class="fas fa-search"></div>
            <div id="user-btn" class="fas fa-user"></div>
            <div id="toggle-btn" class="fas fa-sun"></div>
        </div>

        <div class="profile">
            <img src="<?php echo e(asset('uploaded_files/' . $userImage)); ?>" alt="">
            <h3><?php echo e($userName); ?></h3>
            <span><?php echo e($userProfesi); ?></span>
            <a href="<?php echo e(url('/profileadmin')); ?>" class="btn">View Profile</a>
            <a href="<?php echo e(route('logoutad')); ?>" onclick="return confirm('Anda Yakin Ingin Logout?');" class="delete-btn">Log out</a>
        </div>
    </section>
</header>

<section class="contents">
    <h1 class="heading">Materi Anda</h1>

    <?php if(session('success')): ?>
        <div class="modal-box" id="success-message">
            <i class="fa-solid fa-check-to-slot"></i>
            <h2>Success</h2>
            <h3><?php echo e(session('success')); ?></h3>
            <div class="but">
                <button class="tutupbut" onclick="closeModalAndClearSession()">OK</button>
            </div>
        </div>
    <?php elseif(session('error')): ?>
        <div id="error-message" class="popup-message"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <?php if(session('sucesup')): ?>
        <div class="modal-up" id="success-message">
            <i class="fa-solid fa-thumbs-up"></i>
            <h2>Success</h2>
            <h3><?php echo e(session('sucesup')); ?></h3>
            <div class="butup">
                <button class="tutupbutup" onclick="closeModalAndClearSession()">OK</button>
            </div>
        </div>
    <?php elseif(session('errorup')): ?>
        <div id="error-message" class="popup-message"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <div class="box-container">
        <div class="box" style="text-align: center;">
            <h3 class="title" style="margin-bottom: .5rem;">Buat Materi Baru</h3>
            <a href="<?php echo e(route('add_content')); ?>" class="btn">Tambah</a>
        </div>

        <?php if($contents->count() > 0): ?>
            <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="box">
                    <div class="flex">
                        <div>
                            <i class="fas fa-dot-circle" style="<?php echo e($content->status == 'active' ? 'color:limegreen' : 'color:red'); ?>"></i>
                            <span style="<?php echo e($content->status == 'active' ? 'color:limegreen' : 'color:red'); ?>"><?php echo e($content->status); ?></span>
                        </div>
                        <div>
                            <i class="fas fa-calendar"></i><span><?php echo e($content->date); ?></span>
                        </div>
                    </div>
                    <img src="../uploaded_files/<?php echo e($content->thumb); ?>" class="thumb" alt="">
                    <h3 class="title"><?php echo e($content->title); ?></h3>
                    <form action="<?php echo e(route('delete_video')); ?>" method="post" class="flex-btn">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="video_id" value="<?php echo e($content->id); ?>">
                        <a href="<?php echo e(route('update.content', ['videoId' => $content->id])); ?>" class="option-btn">Ubah</a>
                        <button type="submit" class="delete-btn" onclick="return confirm('Anda Yakin Ingin Menghapus Materi?');">Hapus</button>
                    </form>
                    <a href="<?php echo e(route('watchad.video', ['id' => $content->id])); ?>" class="btn">Lihat Materi</a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <p class="empty">Tidak ada materi yang ditambahkan!</p>
        <?php endif; ?>
    </div>

    <div class="page">
        <div class="pagination">
            <ul> <!-- pages or li are comes from javascript --> </ul>
        </div>
    </div>
</section>

<script>
    function closeModalAndClearSession() {
        document.getElementById('success-message').style.display = 'none';
        // Tambahkan kode untuk menghapus sesi jika diperlukan
    }

    const element = document.querySelector(".pagination ul");
    const totalPages = <?php echo e($totalPages); ?>;
    const currentPage = <?php echo e($currentPage); ?>;

    element.innerHTML = createPagination(totalPages, currentPage);

    function createPagination(totalPages, page) {
        let liTag = '';
        let active;
        let beforePage = page - 1;
        let afterPage = page + 1;
        if (page > 1) {
            liTag += `<li class="newbtn prev" onclick="changePage(${page - 1})"><span><i class="fas fa-angle-left"></i> Prev</span></li>`;
        }

        if (page > 2) {
            liTag += `<li class="first numb" onclick="changePage(1)"><span>1</span></li>`;
            if (page > 3) {
                liTag += `<li class="dots"><span>...</span></li>`;
            }
        }

        // if (page == totalPages) {
        //     beforePage = beforePage - 2;
        // } else if (page == totalPages - 1) {
        //     beforePage = beforePage - 1;
        // }
        if (page == 1) {
            afterPage = afterPage + 2;
        } else if (page == 2) {
            afterPage = afterPage + 1;
        }

        for (var plength = beforePage; plength <= afterPage; plength++) {
            if (plength > totalPages) {
                continue;
            }
            if (plength == 0) {
                plength = plength + 1;
            }
            if (page == plength) {
                active = "active";
            } else {
                active = "";
            }
            liTag += `<li class="numb ${active}" onclick="changePage(${plength})"><span>${plength}</span></li>`;
        }

        if (page < totalPages - 1) {
            if (page < totalPages - 2) {
                liTag += `<li class="dots"><span>...</span></li>`;
            }
            liTag += `<li class="last numb" onclick="changePage(${totalPages})"><span>${totalPages}</span></li>`;
        }

        if (page < totalPages) {
            liTag += `<li class="newbtn next" onclick="changePage(${page + 1})"><span>Next <i class="fas fa-angle-right"></i></span></li>`;
        }
        element.innerHTML = liTag;
        return liTag;
    }

    function changePage(page) {
        const url = new URL(window.location.href);
        url.searchParams.set('page', page);
        window.location.href = url.toString();
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel asik cik\codinggo web fix\resources\views/contentad.blade.php ENDPATH**/ ?>