<!-- <?php
if(isset($message)){
   foreach($message as $message){
      echo '
      <div class="message">
         <span>'.$message.'</span>
         <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
      </div>
      ';
   }
}
?> -->
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Siswa (<?php echo e($userName); ?>)</title>

   <!-- Font Awesome CDN link -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- Custom CSS file link -->
   <link rel="stylesheet" href="<?php echo e(asset('assets/css/dash.css')); ?>">
   <link rel="icon" href="<?php echo e(asset('assets/images/demo/start-hub-2/logo/sidelogo.png')); ?>">

</head>
<body>

<header class="header">
   <section class="flex">
      <a href="<?php echo e(route('courses.index')); ?>" class="logo">Siswa</a>



      <div class="icons">
         <div id="menu-btn" class="fas fa-bars"></div>
         <div id="search-btn" class="fas fa-search"></div>
         <div id="user-btn" class="fas fa-user"></div>
         <div id="toggle-btn" class="fas fa-sun"></div>
      </div>

      <div class="profile">
         <img src="<?php echo e(asset('uploaded_files/' . $userImage)); ?>" alt="">
         <h3><?php echo e($userName); ?></h3>
         <span>student</span>
         <a href="<?php echo e(url('/profileuser')); ?>" class="btn">View Profile</a>
         
         <a href="<?php echo e(route('logoutsiswa')); ?>" onclick="return confirm('Anda Yakin Ingin Logout?');" class="delete-btn">Logout</a>

         

      </div>
   </section>
</header>

<!-- Sidebar section starts  -->
<div class="side-bar">
   <div class="close-side-bar">
      <i class="fas fa-times"></i>
   </div>

   <div class="profile">

      <img src="<?php echo e(asset('uploaded_files/' . $userImage)); ?>" alt="">
      <h3><?php echo e($userName); ?></h3>
      <span>student</span>
      <a href="<?php echo e(url('/profileuser')); ?>" class="btn">View Profile</a>

      

   </div>

   <nav class="navbar">
      
      <a href="<?php echo e(route('courses.index')); ?>"><i class="fas fa-graduation-cap"></i><span>Materi</span></a>
      <a href="teachers.php"><i class="fas fa-chalkboard-user"></i><span>Teachers</span></a>
      <a href="https://wa.me/6285707038940"><i class="fas fa-headset"></i><span>Contact Us</span></a>
      <a href="<?php echo e(route('logoutsiswa')); ?>" onclick="return confirm('Anda Yakin Ingin Logout?');"><i class="fas fa-right-from-bracket"></i><span>Logout</span></a>

   </nav>
</div>
<!-- Sidebar section ends -->

<main>
   <?php echo $__env->yieldContent('main'); ?>
</main>
<script src="<?php echo e(asset('assets/js/user_script.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\laravel asik cik\codinggo web\resources\views/components/userheader.blade.php ENDPATH**/ ?>