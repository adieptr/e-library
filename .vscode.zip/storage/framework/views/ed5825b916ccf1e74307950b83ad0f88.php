<?php $__env->startSection('main'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/dash.css')); ?>">
<script src="<?php echo e(asset('assets/js/user_script.js')); ?>"></script>
<section class="form-container" style="min-height: calc(100vh - 19rem);">

    <form action="<?php echo e(route('user.update', $data->id)); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
       <h3>update profile</h3>
       <div class="flex">
          <div class="col">
             <p>your name</p>
             <input type="text" name="name" placeholder="<?php echo e($data->name); ?>" maxlength="100" class="box">
             <p>your email</p>
             <input type="email" name="email" placeholder="<?php echo e($data->email); ?>" maxlength="100" class="box">
             <p>update pic</p>
             <input type="file" name="image" accept="image/*" class="box">
          </div>
          <div class="col">
                <p>old password</p>
                <input type="password" name="old_pass" placeholder="enter your old password" maxlength="50" class="box">
                <p>new password</p>
                <input type="password" name="new_pass" placeholder="enter your new password" maxlength="50" class="box">
                <p>confirm password</p>
                <input type="password" name="cpass" placeholder="confirm your new password" maxlength="50" class="box">
          </div>
       </div>
       <input type="submit" name="submit" value="update profile" class="btn">
    </form>

 </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.userheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel asik cik\codinggo web\resources\views/updateprofileu.blade.php ENDPATH**/ ?>