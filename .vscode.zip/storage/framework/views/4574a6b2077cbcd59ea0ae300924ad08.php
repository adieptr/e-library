<?php $__env->startSection('main'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/admin_style.css')); ?>">
    <script src="<?php echo e(asset('assets/js/admin_script.js')); ?>"></script>



    <header class="header">

        <section class="flex">

            <a href="<?php echo e(url('/dashboardad')); ?>" class="logo">Tutor</a>



            <div class="icons">
                <div id="menu-btn" class="fas fa-bars"></div>
                <div id="search-btn" class="fas fa-search"></div>
                <div id="user-btn" class="fas fa-user"></div>
                <div id="toggle-btn" class="fas fa-sun"></div>
            </div>

            <div class="profile">

                <img src="<?php echo e(asset('uploaded_files/' . $userImage)); ?>" alt="">
                <h3><?php echo e($userName); ?></h3>
                <span><?php echo e($userProfesi); ?></span>
                <a href="<?php echo e(url('/profileadmin')); ?>" class="btn">View Profile</a>

                <a href="<?php echo e(route('logoutad')); ?>" onclick="return confirm('Anda Yakin Ingin Logout?');"
                    class="delete-btn">Log out</a>

            </div>

        </section>

    </header>

    <section class="video-form">

        <h1 class="heading">Buat Materi</h1>

        <?php if(session('success')): ?>
            <script>
                alert("<?php echo e(session('success')); ?>");
            </script>
        <?php endif; ?>

        <form action="<?php echo e(route('upload_content')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <p>Status Materi<span>*</span></p>
            <select name="status" class="box" required>
                <option value="" selected disabled>-- Pilih status --</option>
                <option value="active">Aktif</option>
                <option value="deactive">Nonaktif</option>
            </select>
            <p>Judul Materi <span>*</span></p>
            <input type="text" name="title" maxlength="100" required placeholder="Masukkan judul materi" class="box">
            <p>Deskripsi Materi <span>*</span></p>
            <textarea name="description" class="box" required placeholder="Masukkan deskripsi" maxlength="1000" cols="30"
                rows="10"></textarea>
            <p>Sesi Kursus <span>*</span></p>
            <select name="playlist" class="box" required>
                <option value="" disabled selected>-- Pilih Kursus --</option>
                <?php if(count($playlists) > 0): ?>
                    <?php $__currentLoopData = $playlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $playlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($playlist->id); ?>"><?php echo e($playlist->title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <option value="" disabled>Tidak ada materi yang dibuat!</option>
                <?php endif; ?>
            </select>
            <p>Unggah Foto Materi <span>*</span></p>
            <input type="file" name="thumb" accept="image/*"  class="box">
            <p>Unggah Video Materi <span>*</span></p>
            <input type="file" name="video" accept="video/*"  class="box">
            <input type="submit" value="Tambah Materi" name="submit" class="btn">
        </form>

    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\farai\OneDrive\Dokumen\SMT 4\Project Codinggo\codinggo web2\resources\views/add_content.blade.php ENDPATH**/ ?>