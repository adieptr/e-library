<?php $__env->startSection('main'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dash.css')); ?>">
    <script src="<?php echo e(asset('assets/js/user_script.js')); ?>"></script>





    


    <section class="watch-video">

        <?php if($video): ?>
            <div class="video-details">
                <video src="<?php echo e(asset('uploaded_files/' . $video->video)); ?>" class="video" poster="<?php echo e(asset('uploaded_files/' . $video->thumb)); ?>" controls autoplay></video>

                <h3 class="title"><?php echo e($video->title); ?></h3>
                <div class="info">
                    <p><i class="fas fa-calendar"></i><span><?php echo e($video->date); ?></span></p>
                </div>
                <?php if($tutor): ?>
                    <div class="tutor">
                        <img src="<?php echo e(asset('uploaded_files/' . $tutor->image)); ?>" alt="">
                        <div>
                            <h3><?php echo e($tutor->name); ?></h3>
                            <span><?php echo e($tutor->profession); ?></span>
                        </div>
                    </div>
                <?php endif; ?>
                

                <div class="description"><p><?php echo e($video->description); ?></p></div>
            </div>
        <?php else: ?>
            <p class="empty">No videos added yet!</p>
        <?php endif; ?>

    </section>

    <section class="comments">

        <h1 class="heading">Add a Comment</h1>

        <form action="<?php echo e(route('video.storeComment', ['videoId' => $video->id])); ?>" method="post" class="add-comment">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="content_id" value="<?php echo e($video->id); ?>">
            <textarea name="comment_box" required placeholder="Write your comment..." maxlength="1000" cols="30" rows="10"></textarea>
            <input type="submit" value="Add Comment" name="add_comment" class="inline-btn">
        </form>

        <div class="show-comments">
            <?php if($comments->count() > 0): ?>
                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="box" style="<?php echo e($comment->user_id == $userId ? 'order:-1;' : ''); ?>">
                        <div class="user">
                            <?php
                                $user = $users->where('id', $comment->user_id)->first();
                            ?>
                            <?php if($user): ?>
                                <img src="<?php echo e(asset('uploaded_files/' . $user->image)); ?>" alt="">
                                <div>
                                    <h3><?php echo e($user->name); ?></h3>
                                    <span><?php echo e($comment->date); ?></span>
                                </div>
                            <?php endif; ?>
                        </div>
                        <p class="text"><?php echo e($comment->comment); ?></p>
                        <?php if($comment->user_id == $userId): ?>
                            <form action="<?php echo e(route('video.editComment', ['videoId' => $video->id, 'commentId' => $comment->id])); ?>" method="post" class="flex-btn">
                                <?php echo csrf_field(); ?>
                                
                            </form>
                            <form action="<?php echo e(route('video.deleteComment', ['videoId' => $video->id, 'commentId' => $comment->id])); ?>" method="post" class="flex-btn">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" name="delete_comment" class="inline-delete-btn" onclick="return confirm('Delete this comment?');">Delete Comment</button>
                            </form>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <p class="empty">No comments added yet!</p>
            <?php endif; ?>
        </div>

    </section>

    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.userheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel asik cik\codinggo web\resources\views/watch_video.blade.php ENDPATH**/ ?>