<?php $__env->startSection('main'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

<header class="header">

    <section class="flex">

        <a href="<?php echo e(url('/dashboardsp')); ?>" class="logo">Admin</a>

        <form action="<?php echo e(route('pages.carisiswasp')); ?>" method="post" class="search-form">
            <?php echo csrf_field(); ?>
            <input type="text" name="search" placeholder="Cari Siswa..." required maxlength="100">
            <button type="submit" class="fas fa-search" name="search_btn"></button>
        </form>

        <div class="icons">
            <div id="menu-btn" class="fas fa-bars"></div>
            <div id="search-btn" class="fas fa-search"></div>
            <div id="user-btn" class="fas fa-user"></div>
            <div id="toggle-btn" class="fas fa-sun"></div>
        </div>

        <div class="profile">

            <img src="<?php echo e(asset('uploaded_files/' . $userImage)); ?>" alt="">
            <h3><?php echo e($userName); ?></h3>
            <span><?php echo e($userProfesi); ?></span>
            <a href="<?php echo e(url('/profilesp')); ?>" class="btn">view profile</a>

            <a href="<?php echo e(route('logoutsp')); ?>" onclick="return confirm('Anda Yakin Ingin Logout?');"
                class="delete-btn">log out</a>

        </div>

    </section>

</header>


    <section class="dashboard">






        <div class="content">

            <main>
                

                <!-- Insights -->
                <ul class="insights">
                    <a href="<?php echo e(route('tutor.index')); ?>">
                        <li>
                            <i class='bx bx-book-open'></i>
                            <span class="info">
                                <h3>
                                    <?php echo e($totalTutors); ?>

                                </h3>
                                <p>Total Tutor</p>
                            </span>
                        </li>
                    </a>

                    <a href="<?php echo e(route('siswa.index')); ?>">
                        <li><i class='bx bx-user'></i>
                            <span class="info">
                                <h3>
                                    <?php echo e($totalUsers); ?>

                                </h3>
                                <p>Total Siswa</p>
                            </span>
                        </li>
                    </a>

                    <a href="<?php echo e(route('commentsad')); ?>">
                        <li><i class='bx bx-dollar-circle'></i>
                            <span class="info">
                                <h4 style="font-size: 17px">
                                    Rp  <?php echo e(number_format($totalHargaTransaksi, 0, ',', '.')); ?>

                                </h4>
                                <p>Total Pendapatan</p>
                            </span>
                        </li>
                    </a>

                    <a href="">
                        <li><i class='bx bx-user'></i>
                            <span class="info">
                                <h3>
                                    <?php echo e($jumlahTransaksiPending); ?>

                                </h3>
                                <p>Total Transaksi Pending</p>
                            </span>
                        </li>
                    </a>
                </ul>
                <!-- End of Insights -->

                <div class="bottom-data">
                    <div class="orders">
                        <div class="header2">
                            <i class='bx bx-receipt'></i>
                            <h3>Data Keuangan</h3>
                        </div>
                        <table>
                            <thead>
                                <tr>
                                    <th>Siswa</th>
                                    <th>Email</th>
                                    <th>Kursus</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $dtlsiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <img src="<?php echo e(asset('uploaded_files/' . $item->user->image)); ?>" alt="">
                                        <p style="font-size: 20px"><?php echo e($item->user->name); ?></p>
                                    </td>
                                    <td>
                                        <p style="font-size: 20px"><?php echo e($item->user->email); ?></p>
                                    </td>
                                    <td style="font-size: 20px">
                                        <?php if(isset($item->playlist) && isset($item->playlist->title)): ?>
                                            <?php echo e($item->playlist->title); ?>

                                        <?php else: ?>
                                            Nama Kursus Tidak Tersedia
                                        <?php endif; ?>
                                    </td>
                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                </div>

            </main>

        </div>




    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.spheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel asik cik\codinggo web2\resources\views/dashboardsp.blade.php ENDPATH**/ ?>