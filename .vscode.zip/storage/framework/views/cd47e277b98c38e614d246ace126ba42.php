<?php $__env->startSection('main'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

    <header class="header">

        <section class="flex">

            <a href="<?php echo e(url('/dashboardsp')); ?>" class="logo">Admin.</a>

            <form action="<?php echo e(route('pages.carisiswasp')); ?>" method="post" class="search-form">
                <?php echo csrf_field(); ?>
                <input type="text" name="search" placeholder="Cari Siswa..." required maxlength="100">
                <button type="submit" class="fas fa-search" name="search_btn"></button>
            </form>

            <div class="icons">
                <div id="menu-btn" class="fas fa-bars"></div>
                <div id="search-btn" class="fas fa-search"></div>
                <div id="user-btn" class="fas fa-user"></div>
                <div id="toggle-btn" class="fas fa-sun"></div>
            </div>

            <div class="profile">

                <img src="<?php echo e(asset('uploaded_files/' . $userImage)); ?>" alt="">
                <h3><?php echo e($userName); ?></h3>
                <span><?php echo e($userProfesi); ?></span>
                <a href="<?php echo e(url('/profilesp')); ?>" class="btn">view profile</a>

                <a href="<?php echo e(route('logoutsp')); ?>" onclick="return confirm('Anda Yakin Ingin Logout?');"
                    class="delete-btn">logout</a>

            </div>

        </section>

    </header>


    <section class="dashboard">






        <div class="content">

            <main>


                <div class="bottom-data">
                    <div class="orders">
                        <div class="header2">
                            <i class='bx bx-receipt'></i>
                            <h3>Data Keuangan</h3>
                        </div>
                        <table>
                            <thead>
                                <tr>
                                    <th>Siswa</th>
                                    <th>Kursus</th>
                                    <th>Harga</th>
                                    <th>Status</th>
                                    <th>Tanggal</th>
                                    <th>Bukti Pembayaran</th>
                                    
                                    <th style="text-align: center;">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <img src="<?php echo e(asset('uploaded_files/' . $transaction->user->image)); ?>"
                                                alt="">
                                            <p style="font-size: 15px"><?php echo e($transaction->user->name); ?></p>
                                        </td>
                                        <td style="font-size: 15px">
                                            <?php if($transaction->playlist): ?>
                                                <?php echo e($transaction->playlist->title); ?>

                                            <?php else: ?>
                                                Nama Kursus Tidak Tersedia
                                            <?php endif; ?>
                                        </td>
                                        <td style="font-size: 15px">
                                            <?php if($transaction->playlist): ?>
                                                Rp.<?php echo e(number_format($transaction->playlist->harga, 0, ',', '.')); ?>

                                            <?php else: ?>
                                                Nama Kursus Tidak Tersedia
                                            <?php endif; ?>
                                        </td>
                                        <td style="font-size: 15px">
                                            <?php echo e($transaction->status); ?>

                                        </td>
                                        <td style="font-size: 15px">
                                            <?php if($transaction->tanggal): ?>
                                                <?php echo e($transaction->tanggal); ?>

                                            <?php else: ?>
                                                Bukti Pembayaran Tidak Tersedia
                                            <?php endif; ?>
                                        </td>
                                        <td style="font-size: 15px; text-align: center;">
                                            <?php if($transaction->bukti_pembayaran): ?>
                                                <img src="<?php echo e(asset('uploaded_files/' . $transaction->bukti_pembayaran)); ?>"
                                                    alt="Bukti Pembayaran" style="border-radius: 0; ">
                                            <?php else: ?>
                                                Bukti Pembayaran Tidak Tersedia
                                            <?php endif; ?>
                                        </td>
                                        <td style="text-align: center;">
                                            <div class="aksi">
                                                <a href="<?php echo e(route('transaksi.tampiluptra', $transaction->id_transaksi)); ?>" class="tomedit">Edit</a>
                                                <a href="#" class="tomhapus">Hapus</a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                    

                </div>

            </main>

        </div>




    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.spheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\farai\OneDrive\Dokumen\SMT 4\Project Codinggo\codinggo\codinggo web2\resources\views/datatransaksi.blade.php ENDPATH**/ ?>