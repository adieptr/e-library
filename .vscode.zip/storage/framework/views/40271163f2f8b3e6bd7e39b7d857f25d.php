<?php $__env->startSection('main'); ?>
<link rel="stylesheet" href="assets/css/dash.css">
<section class="profile">

    <h1 class="heading">profile details</h1>

    <div class="details">

       <div class="user">
          <img src="<?php echo e(asset('uploaded_files/' . $userImage)); ?>">
          <h3><?php echo e($userName); ?></h3>
          <p>student</p>
          <a href="<?php echo e(route('user.edit', $userId)); ?>" class="inline-btn">update profile</a>
       </div>

       

    </div>

 </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.userheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel asik cik\codinggo web2\resources\views/profileuser.blade.php ENDPATH**/ ?>