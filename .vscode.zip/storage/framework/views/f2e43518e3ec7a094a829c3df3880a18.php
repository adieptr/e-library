<?php $__env->startSection('main'); ?>

<section class="courses">

    <h1 class="heading">Daftar Materi</h1>

    <div class="box-container">

        <?php $__empty_1 = true; $__currentLoopData = $playlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $playlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="box">
            <div class="tutor">
                <img src="uploaded_files/<?php echo e($playlist->tutor->image); ?>" alt="">
                <div>
                    <h3><?php echo e($playlist->tutor->name); ?></h3>
                    <span><?php echo e($playlist->date); ?></span>
                </div>
            </div>
            <img src="uploaded_files/<?php echo e($playlist->thumb); ?>" class="thumb" alt="">
            <h3 class="title"><?php echo e($playlist->title); ?></h3>
            <a href="<?php echo e(route('playlist.showPlaylist', ['id' => $playlist->id])); ?>" class="inline-btn">Lihat Playlist</a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="empty">Belum ada kursus ditambahkan!</p>
        <?php endif; ?>

    </div>

</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.userheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel asik cik\codinggo web\resources\views/courses.blade.php ENDPATH**/ ?>